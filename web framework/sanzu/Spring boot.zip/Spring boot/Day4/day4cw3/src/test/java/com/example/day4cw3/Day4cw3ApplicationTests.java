package com.example.day4cw3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Day4cw3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
