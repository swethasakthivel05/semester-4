package com.example.jpa.controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.jpa.model.StudentDetails;
import com.example.jpa.services.StudentServices;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
public class StudentController {

    private StudentServices studentServices;

    public StudentController(StudentServices studentServices)
    {
        this.studentServices = studentServices;
    }

    @PostMapping("/poststudent")
    public StudentDetails postMethodName(@RequestBody StudentDetails studentDetails) {
        
        studentServices.saveStudentDetails(studentDetails);
        return studentDetails;
    }
    
}
