package com.example.demo.controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.StudentModel;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
public class PostMappingDemo {
    @PostMapping("/post")
    public String postMethodName(@RequestBody String entity) {
        return entity;
    }
    
    @PostMapping("/modelpost")
    public StudentModel postMethodName(@RequestBody StudentModel entity) {
        return entity;
    }
    

    
}
