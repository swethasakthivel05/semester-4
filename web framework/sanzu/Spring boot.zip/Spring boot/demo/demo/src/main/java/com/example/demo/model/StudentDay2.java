package com.example.demo.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class StudentDay2 {
    @JsonProperty("Student created")
    private String name;
    @JsonProperty("Age")
    private int age;
    public StudentDay2(String name, int age) {
        this.name = name;
        this.age = age;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    
}
