package com.example.demo.controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Book;

import java.util.Date;

import org.springframework.web.bind.annotation.GetMapping;



@RestController
public class Day2_cw_4 {
    @GetMapping("/book")
    public Book getMethodName() {
        Date date = new Date();
        Book obj = new Book("The Great Soldier","G.Gyan",date);
        return obj;
    }
    
}
