package com.example.demo.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ConfigApp {
    private String studentName;
    private String studentDepartment;
    
    public ConfigApp() {
    }
    public ConfigApp(String studentName, String studentDepartment) {
        this.studentName = studentName;
        this.studentDepartment = studentDepartment;
    }
    public String getStudentName() {
        return studentName;
    }
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
    public String getStudentDepartment() {
        return studentDepartment;
    }
    public void setStudentDepartment(String studentDepartment) {
        this.studentDepartment = studentDepartment;
    }
    
}
