package com.example.demo.controller;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Student;

import org.springframework.web.bind.annotation.GetMapping;



@RestController
public class Day2_cw_3 {
    @GetMapping("/description")
    public Student getMethodName() {
        Student obj = new Student(1L,"John Doe","This is a student description");
        return obj;
    }
    
}
