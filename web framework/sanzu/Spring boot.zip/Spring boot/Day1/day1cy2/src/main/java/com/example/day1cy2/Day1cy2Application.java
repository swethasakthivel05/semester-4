package com.example.day1cy2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day1cy2Application {

	public static void main(String[] args) {
		SpringApplication.run(Day1cy2Application.class, args);
	}

}
