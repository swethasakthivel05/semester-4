package com.student.student.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.student.student.Model.Donor;
import com.student.student.Service.DonorService;

@RestController
public class ApiController {
    @Autowired
    public DonorService donorService;

    @PostMapping("/")
    public Donor postStudent(@RequestBody Donor donor)
    {
        donorService.PostData(donor);
        return donor;
    }

    @PutMapping("/put/{id}")
    public Donor putStudent(@RequestBody Donor donor,@PathVariable int id)
    {
        return donorService.putData(id, donor);
    }

    @GetMapping("/get")
    public List<Donor> getAll()
    {
        return donorService.getAll();
    }
    @GetMapping("/get/id/{id}")
    public Donor getById(@PathVariable int id)
    {
        return donorService.getById(id);
    }
    @DeleteMapping("/del/{id}")
    public void deleteById(@PathVariable int id)
    {
        donorService.delData(id);
    }

    @GetMapping("/get/field/{field}")
    public List<Donor> getBySort(@PathVariable String field)
    {
        return donorService.getBySort(field);
    }

    @GetMapping("/get/{min}/{max}")
    public List<Donor> getByBetween(@PathVariable int min,@PathVariable int max)
    {
        return donorService.getByBetween(min, max);
    }
}
