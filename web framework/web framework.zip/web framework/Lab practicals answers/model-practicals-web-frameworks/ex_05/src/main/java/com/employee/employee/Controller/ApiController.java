package com.employee.employee.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.employee.employee.Model.Employee;
import com.employee.employee.Service.EmployeeService;

@RestController
public class ApiController {
    @Autowired
    public EmployeeService employeeService;

    @PostMapping("/")
    public Employee postData(@RequestBody Employee employee)
    {
        employeeService.postData(employee);
        return employee;
    }

    @GetMapping("/getstart/{name}")
    public List<Employee> getStartWith(@PathVariable String name)
    {
        return employeeService.getByStartWith(name);
    }
    @GetMapping("/getends/{name}")
    public List<Employee> getEndsWith(@PathVariable String name)
    {
        return employeeService.getByEndsWith(name);
    }
    @GetMapping("/getcontains/{name}")
    public List<Employee> getContains(@PathVariable String name)
    {
        return employeeService.getByContains(name);
    }
    @GetMapping("/getcontaining/{name}")
    public List<Employee> getContaining(@PathVariable String name)
    {
        return employeeService.getByContaining(name);
    }
    @GetMapping("/getIscontaining/{name}")
    public List<Employee> getIsContaining(@PathVariable String name)
    {
        return employeeService.getByIsContaining(name);
    }
}
