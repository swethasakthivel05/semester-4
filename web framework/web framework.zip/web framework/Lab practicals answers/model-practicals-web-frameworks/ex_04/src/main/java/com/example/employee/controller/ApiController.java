package com.example.employee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import com.example.employee.model.Employee;
import com.example.employee.service.EmployeeService;

import java.util.List;
import java.time.LocalDate;

@RestController
public class ApiController {
    @Autowired
    private EmployeeService employeeService;
    @PostMapping("/")
    public boolean addEmployee(@RequestBody Employee employee) {
        return employeeService.addEmployee(employee);
    }
    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable("id") int id) {
        return employeeService.getEmployeeById(id);
    }
    @GetMapping("/")
    public List<Employee> getAllEmployees() {
        return employeeService.getAllEmployees();
    }
    @GetMapping("/employees/first-three-characters-of-first-name")
    public List<String> getFirstThreeCharactersOfFirstName() {
        return employeeService.getFirstThreeCharactersOfFirstName();
    }
    @GetMapping("/employees/hired/{hireDate}")
    public List<Employee> getEmployeesHiredOnDate(@PathVariable("hireDate") LocalDate hireDate) {
        return employeeService.getEmployeesHiredOnDate(hireDate);
    }
}
