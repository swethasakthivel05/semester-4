package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Joke;
import com.example.demo.service.JokeService;

@RestController
@RequestMapping("/api/jokes")
public class ApiController {
    
    @Autowired
    private JokeService jokeService;

    @GetMapping("/categories")
    public List<String> getCategories() {
        return jokeService.getCategories();
    }

    @GetMapping("/random")
    public Joke getByCategory(@RequestParam String[] category) {
        return jokeService.getRandomJoke(category);
    }

    @GetMapping("/randomById")
    public Joke getById(@RequestParam String query) {
        return jokeService.getRandomJokeById(query);
    }

    @GetMapping("/randomExclude")
    public Joke exclude(@RequestParam String[] exclude) {
        return jokeService.getRandomJokeExclude(exclude);
    }

    @GetMapping("/randomInclude")
    public Joke include(@RequestParam String[] include) {
        return jokeService.getRandomJokeInclude(include);
    }
}
