package com.example.jokedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JokedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
