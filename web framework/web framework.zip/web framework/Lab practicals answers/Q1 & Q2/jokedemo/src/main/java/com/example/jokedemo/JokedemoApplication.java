package com.example.jokedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JokedemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(JokedemoApplication.class, args);
	}

}
