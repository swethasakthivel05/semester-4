package com.example.TestCases;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
//import org.junit.AfterClass;
//import org.junit.BeforeClass;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.example.Util.ReadConfig;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
    ReadConfig config = new ReadConfig();
    String url = config.getUrl();

    String userName = config.getUsername();
    String password = config.getPassword();
    WebDriver driver;
    Logger log;

    @BeforeClass
    public void setup() {
        WebDriverManager.chromedriver().setup();
        driver = new ChromeDriver();
        log = Logger.getLogger(BaseClass.class);
        PropertyConfigurator.configure(
                "C:\\Users\\Swetha\\Documents\\semester 4\\software testing\\testingframeworks2\\src\\main\\java\\com\\example\\resources\\log4j.properties");
    }

    @AfterClass
    public void quitDriver() {
        driver.quit();
    }
}
