package com.example;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * Unit test for simple App.
 */
public class AppTest {
    /**
     * * Rigorous Test :-)
     * 
     * @throws InterruptedException
     */
    @Test
    public void shouldAnswerWithTrue() throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.shoppersstop.com/");
        Thread.sleep(4000);
        driver.findElement(By.xpath("//*[@id='profileImage']/a/i"));
        Thread.sleep(2000);
        driver.quit();
    }
}
